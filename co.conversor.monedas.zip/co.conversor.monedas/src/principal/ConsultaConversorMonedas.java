/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package principal;

import java.io.IOException;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;

/**
 *
 * @author SDH
 */
public class ConsultaConversorMonedas {
        String json;
    public String busquedaMonedas() {
        
        URI direccion = URI.create("https://v6.exchangerate-api.com/v6/0bfd3f6d858a375dbf3315b0/latest/USD");
        HttpClient client = HttpClient.newHttpClient();
        HttpRequest request = HttpRequest.newBuilder()
                .uri(direccion)
                .build();

        try {
            HttpResponse<String> response = client
                    .send(request, HttpResponse.BodyHandlers.ofString());
            json = response.body();
            // System.out.println(json);
             
        } catch (Exception e) {

            System.out.println("error mostrando pila de errores ");
            e.printStackTrace();
            

        }
     return json;
    }
}
