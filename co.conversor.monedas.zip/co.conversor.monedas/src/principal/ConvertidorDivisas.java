/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package principal;

import com.google.gson.JsonObject;
import java.awt.Dimension;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;

/**
 *
 * @author SDH
 */
public class ConvertidorDivisas {
      private final JsonObject tasasDeCambio;

    // Constructor para inicializar con las tasas de cambio
    public ConvertidorDivisas(JsonObject tasasDeCambio) {
        this.tasasDeCambio = tasasDeCambio;
    }

    // Método para obtener la tasa de cambio de una divisa específica
    private double obtenerTasa(String codigoDivisa) {
        return tasasDeCambio.has(codigoDivisa) ? tasasDeCambio.get(codigoDivisa).getAsDouble() : -1;
    }

    // Método principal para convertir entre dos monedas
    public double convertirDivisa(double cantidad, String desdeDivisa, String haciaDivisa) {
        double tasaDesde = obtenerTasa(desdeDivisa);
        double tasaHacia = obtenerTasa(haciaDivisa);

        if (tasaDesde == -1 || tasaHacia == -1) {
            System.out.println("Una o ambas divisas no están disponibles en las tasas de cambio.");
            return -1;
        }

        // Realizar la conversión
        return (cantidad / tasaDesde) * tasaHacia;
    }

    // Método para listar las divisas disponibles
    public void listarDivisasDisponibles() {
    
            StringBuilder mensaje = new StringBuilder("Divisas disponibles:\n");
    for (String codigoDivisa : tasasDeCambio.keySet()) {
        mensaje.append(codigoDivisa)
               .append(" - Tasa: ")
               .append(tasasDeCambio.get(codigoDivisa).getAsDouble())
               .append("\n");
    }
    
             // Crear un JTextArea con el mensaje y configurarlo como no editable
    JTextArea textArea = new JTextArea(mensaje.toString());
    textArea.setEditable(false);
    
    // Ajustar el tamaño de JTextArea para que sea adecuado para el contenido
    textArea.setColumns(30);
    textArea.setRows(10);
    
    // Crear un JScrollPane para añadir desplazamiento (scroll) a JTextArea
    JScrollPane scrollPane = new JScrollPane(textArea);
    scrollPane.setPreferredSize(new Dimension(400, 200)); // Ajustar el tamaño según sea necesario
    
    // Mostrar el JScrollPane en el JOptionPane
    JOptionPane.showMessageDialog(null, scrollPane, "Lista de Divisas Disponibles", JOptionPane.INFORMATION_MESSAGE);
        
        
        
        /*     System.out.println("Divisas disponibles:");
        for (String codigoDivisa : tasasDeCambio.keySet()) {
            System.out.println(codigoDivisa + " - Tasa: " + tasasDeCambio.get(codigoDivisa).getAsDouble());
        }*/
    }
}
