/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package principal;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import java.util.InputMismatchException;
import java.util.Scanner;
import javax.swing.JOptionPane;

/**
 *
 * @author SDH
 */
public class Principal {

    public static void main(String[] args) {
        Scanner entrada = new Scanner(System.in);
        ConversionObjeto conversion = new ConversionObjeto();
        JsonObject conversionRates = conversion.conversionObj();

        ConvertidorDivisas convertidor = new ConvertidorDivisas(conversionRates);

        boolean continuar = true;
        int opcion = 1;
        while (continuar) {
            try {
                // Menú de opciones
                String opcionStr = JOptionPane.showInputDialog(null,
                        "=== Menú de Conversión de Divisas ===\n"
                        + "1. Convertir divisa\n"
                        + "2. Listar divisas disponibles\n"
                        + "3. Salir\n\n"
                        + "Seleccione una opción:",
                        "Menú de Conversión", JOptionPane.QUESTION_MESSAGE);

                if (opcionStr == null) {
                    break;  // Salir si el usuario cancela
                }
                opcion = Integer.parseInt(opcionStr);

                switch (opcion) {
                    case 1:
                        // Ingreso de cantidad
                        String cantidadStr = JOptionPane.showInputDialog(null,
                                "Ingrese la cantidad a convertir:",
                                "Conversión de Divisa", JOptionPane.QUESTION_MESSAGE);
                        if (cantidadStr == null) {
                            continue;
                        }
                        double cantidad = Double.parseDouble(cantidadStr);

                        // Ingreso de divisa de origen
                        String desdeDivisa = JOptionPane.showInputDialog(null,
                                "Ingrese la divisa de origen (por ejemplo, USD):",
                                "Divisa de Origen", JOptionPane.QUESTION_MESSAGE).toUpperCase();
                        if (desdeDivisa == null) {
                            continue;
                        }

                        // Ingreso de divisa de destino
                        String haciaDivisa = JOptionPane.showInputDialog(null,
                                "Ingrese la divisa de destino (por ejemplo, COP):",
                                "Divisa de Destino", JOptionPane.QUESTION_MESSAGE).toUpperCase();
                        if (haciaDivisa == null) {
                            continue;
                        }

                        // Realizar la conversión
                        double resultado = convertidor.convertirDivisa(cantidad, desdeDivisa, haciaDivisa);
                        if (resultado != -1) {
                            JOptionPane.showMessageDialog(null,
                                    String.format("%.2f %s en %s: %.2f", cantidad, desdeDivisa, haciaDivisa, resultado),
                                    "Resultado de la Conversión", JOptionPane.INFORMATION_MESSAGE);
                        } else {
                            JOptionPane.showMessageDialog(null,
                                    "Conversión no válida. Verifique las divisas ingresadas.",
                                    "Error", JOptionPane.ERROR_MESSAGE);
                        }
                        break;

                    case 2:
                        // Listar divisas disponibles
                        convertidor.listarDivisasDisponibles();
                        break;

                    case 3:
                        // Salir del programa
                        JOptionPane.showMessageDialog(null,
                                "Saliendo del programa...",
                                "Salida", JOptionPane.INFORMATION_MESSAGE);
                        continuar = false;
                        break;

                    default:
                        JOptionPane.showMessageDialog(null,
                                "Opción no válida. Por favor, intente de nuevo.",
                                "Error", JOptionPane.WARNING_MESSAGE);
                }
            } catch (NumberFormatException e) {
                JOptionPane.showMessageDialog(null,
                        "Entrada no válida. Por favor, intente de nuevo.",
                        "Error", JOptionPane.ERROR_MESSAGE);
            }
        }

        //CODIGO DE PRUEBAS
        /*
          double resultado = convertidor.convertirDivisa(100, "USD", "EUR");
        System.out.println("100 USD en EUR: " + resultado);

      
        resultado = convertidor.convertirDivisa(100, "USD", "COP");
        System.out.println("100 COP en ARS: " + resultado);
        
        
         */

 /*
        double usd = conversionRates.get("USD").getAsDouble();
        System.out.println("Tasa original de USD: " + usd);
        double cop = conversionRates.get("COP").getAsDouble();
        System.out.println("Tasa original de COP-COLOMBIA: " + cop);
        double clp = conversionRates.get("CLP").getAsDouble();
        System.out.println("Tasa original de CLP CHILE: " + clp);
        double ars = conversionRates.get("ARS").getAsDouble();
        System.out.println("Tasa original de ARS ARGENTINO: " + ars);
        double bob = conversionRates.get("BOB").getAsDouble();
        System.out.println("Tasa original de BOB Boliviano : " + bob);
        double brl = conversionRates.get("BRL").getAsDouble();
        System.out.println("Tasa original de CLP CHILE: " + brl);
         */
 /*
           Modificar la tasa de USD
        conversionRates.addProperty("USD", 1.15);
        
         Ver la nueva tasa de USD
        System.out.println("Nueva tasa de USD: " + conversionRates.get("USD").getAsDouble());
        
         Ver el JSON modificado
        System.out.println("JSON modificado: " + jsonObject.toString());
       try {
                
                
                System.out.println("\n=== Menú de Conversión de Divisas ===");
                System.out.println("1. Convertir divisa");
                System.out.println("2. Listar divisas disponibles");
                System.out.println("3. Salir");
                System.out.print("Seleccione una opción: ");
                
                opcion = entrada.nextInt();
                entrada.nextLine(); // Limpiar el buffer de entrada
          
            switch (opcion) {
                case 1:
                    System.out.print("Ingrese la cantidad a convertir: ");
                    double cantidad = entrada.nextDouble();
                    entrada.nextLine(); // Limpiar el buffer de entrada

                    System.out.print("Ingrese la divisa de origen (por ejemplo, USD): ");
                    String desdeDivisa = entrada.nextLine().toUpperCase();

                    System.out.print("Ingrese la divisa de destino (por ejemplo, COP): ");
                    String haciaDivisa = entrada.nextLine().toUpperCase();

                    double resultado = convertidor.convertirDivisa(cantidad, desdeDivisa, haciaDivisa);
                    if (resultado != -1) {
                        System.out.printf("%.2f %s en %s: %.2f\n", cantidad, desdeDivisa, haciaDivisa, resultado);
                    }
                    break;

                case 2:
                    convertidor.listarDivisasDisponibles();
                    break;

                case 3:
                    System.out.println("Saliendo del programa...");
                    continuar = false;
                    break;

                default:
                    System.out.println("Opción no válida. Por favor, intente de nuevo.");
            }

              } catch (Exception e) {
                System.out.println("Opción no válida. Por favor, intente de nuevo..");
                entrada.nextLine();

            }
        }
        
         */
    }

}


