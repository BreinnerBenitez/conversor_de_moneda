/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package principal;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

/**
 *
 * @author SDH
 */
public class ConversionObjeto {

    public JsonObject conversionObj() {

        ConsultaConversorMonedas probandojson = new ConsultaConversorMonedas();
        String jsonString = probandojson.busquedaMonedas();
        // Parsear el JSON String en un JsonElement
        JsonElement jsonElemento = JsonParser.parseString(jsonString);

        // Convertir JsonElement a JsonObject para acceder a sus propiedades
        JsonObject jsonObject = jsonElemento.getAsJsonObject();

        // Acceder a la clave "conversion_rates", que es otro JsonObject
        JsonObject conversionRates = jsonObject.getAsJsonObject("conversion_rates");

        return conversionRates;
    }

}
